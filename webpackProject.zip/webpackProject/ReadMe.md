Project 4: Natural Language Processing with NLP
The project is built using webpack, babel, and other dependencies
Api was fetched from the sentiment analysis website
The app has been tested using the jest library